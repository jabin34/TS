#include "common/LteControlInfo.h"
#include "stack/phy/ChannelModel/LteChannelModel.h"
#include <assert.h>
#include <inet/common/INETDefs.h>
#include <ctime>
#include <vector>
#include <numeric>
#ifndef STACK_PHY_LAYER_CALPARAMETER_H_
#define STACK_PHY_LAYER_CALPARAMETER_H_


class calParameter {
public:
    calParameter();
    virtual ~calParameter();

     static const int NUM_TOWERS = 4;
        double bsLoad[NUM_TOWERS] = {0};
        double towerLoad_global = 0;
        // Add variables to store predicted loads
            //double predictedLoad4G_global;
           //double predictedLoad5G_global;
        double prediction_4g; // Store prediction
            double prediction_5g; // Store prediction
            double getPrediction4G() const { return prediction_4g; } // Getter
             double getPrediction5G() const { return prediction_5g; } // Getter
     double calculateEachTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame);
//    void calculateTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame);
//    double towerLoad(LteAirFrame* frame, UserControlInfo* lteInfo);
    double getDoubleValueFile(std::string filepath);
   // void calculateTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame);
    void runGPR();
    void runLSTM();
   // void runLSTM();
   // void saveArrayToFile(const std::string& fileName, const std::vector<double>& array);
  //  double getParfromFile(std::string filepath) ;
    //double towerLoad(LteAirFrame* frame, UserControlInfo* lteInfo);

};

#endif
