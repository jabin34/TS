#include <assert.h>
#include "stack/phy/layer/LtePhyUe.h"
#include <ctime>
#include <vector>
#include <numeric>
#include <iostream>
#include <cmath>
#include "calParameter.h"



std::string baseFilePath ="/home/israt/OMNETPP/ts/simu5G/src/data/";
double bsLoadCal1Weighted;
const int NUM_TOWERS = 4;
double bsLoad[NUM_TOWERS] = {0};  // Use an array to store bsLoad values
double bsLoadCal1[NUM_TOWERS] = {0};
double minLoad = -4;
double minTowerLoad, avgLoad, sumbsLoadCal1, towerCount;
double towerLoad_cur_simtime = 0, eachTowerLoad_cur_simtime = 0;

calParameter::calParameter()
{
    //constructor
}
calParameter::~calParameter()
{
    //destructor
}

double calParameter::calculateEachTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame)
{
    int index = lteInfo->getSourceId()-1;
//    std::cout << "TowerId: " << index + 1 << endl;

//    int totalVehicles = 10;
    int totalVehicles = (int)getDoubleValueFile(baseFilePath+"nodeCount.txt");
//    std::cout << "totalVehicles: " << totalVehicles << endl;
    if (bsLoad[index]<totalVehicles)
        bsLoad[index]++;
//    std::cout << "Tower Load (bsLoad): " << bsLoad[index] << endl;

    bsLoadCal1Weighted = (bsLoad[index] + 4) / (std::accumulate(bsLoad, bsLoad + NUM_TOWERS, 0) + 4);
//    if (simTime().dbl() != eachTowerLoad_cur_simtime)
    if((int)simTime().dbl() % 3 == 0)
    {
        bsLoad[index] = {0};
        bsLoadCal1Weighted = 0;
//        eachTowerLoad_cur_simtime = simTime().dbl();
    }
    towerLoad_global = bsLoadCal1Weighted;
    return bsLoadCal1Weighted;
}
// In calParameter.cc
//void calParameter::runLSTM() {
//    std::string lstmCmd = "python3 " + baseFilePath + "lstm.py";
//    std::cout << "Executing LSTM script: " << lstmCmd << std::endl;
//    int result = system(lstmCmd.c_str());
//    if (result != 0) {
//        std::cerr << "Error: Failed to execute LSTM script!" << std::endl;
//    }
//}
//double calParameter::calculateEachTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame) {
//    int index = lteInfo->getSourceId() - 1;
//    if (index < 0 || index >= NUM_TOWERS) {
//        std::cerr << "Error: Tower ID " << lteInfo->getSourceId() << " out of bounds (index " << index << ")" << std::endl;
//        return 0.0;
//    }
//    int totalVehicles = (int)getDoubleValueFile(calParameter_filePath + "nodeCount.txt");
//    if (totalVehicles <= 0) totalVehicles = 1; // Avoid division issues
//    if (bsLoad[index] < totalVehicles) bsLoad[index]++;
//    double totalLoad = std::accumulate(bsLoad, bsLoad + NUM_TOWERS, 0.0);
//    if (totalLoad == 0) totalLoad = 1.0;
//    bsLoadCal1Weighted = static_cast<double>(bsLoad[index]) / totalVehicles;
//    towerLoad_global = bsLoadCal1Weighted;
//    std::cout << "bsLoad[" << index << "]: " << bsLoad[index] << ", TotalVehicles: " << totalVehicles << ", Load: " << bsLoadCal1Weighted << std::endl;
//    return bsLoadCal1Weighted;
//}



//double calParameter::calculateEachTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame)
//{
//    int index = lteInfo->getSourceId()-1;
////    std::cout << "TowerId: " << index + 1 << endl;
//
////    int totalVehicles = 10;
//    int totalVehicles = (int)getDoubleValueFile(calParameter_filePath+"nodeCount.txt");
////    std::cout << "totalVehicles: " << totalVehicles << endl;
//    if (bsLoad[index]<totalVehicles)
//        bsLoad[index]++;
////    std::cout << "Tower Load (bsLoad): " << bsLoad[index] << endl;
//
//    bsLoadCal1Weighted = (bsLoad[index] + 6) / (std::accumulate(bsLoad, bsLoad + NUM_TOWERS, 0) + 6);
////    if (simTime().dbl() != eachTowerLoad_cur_simtime)
//    if((int)simTime().dbl() % 3 == 0)
//    {
//        bsLoad[index] = {0};
//        bsLoadCal1Weighted = 0;
////        eachTowerLoad_cur_simtime = simTime().dbl();
//    }
//    towerLoad_global = bsLoadCal1Weighted;
//    return bsLoadCal1Weighted;
//}
//




//void calParameter::saveArrayToFile(const std::string& fileName, const std::vector<double>& array) {
//    std::ofstream file(baseFilePath + fileName);
//    for (const auto& value : array) {
//        file << value << "\t";
//    }
//}
//
//
//
//void calParameter::calculateTowerLoad(UserControlInfo* lteInfo, LteAirFrame* frame) {
//       int index = lteInfo->getSourceId()-1;
////       std::cout << "LtePhyUe::calculateTowerLoad -> Tower: " << index << endl;
//       bsLoad[index]++;
////       std::cout << "LtePhyUe::calculateTowerLoad -> bsLoad: " << bsLoad[index] << endl;
//       bsLoadCal1Weighted = (bsLoad[index] + 4) / (std::accumulate(bsLoad, bsLoad + NUM_TOWERS, 0) + 4);
//
//       if (simTime().dbl() != towerLoad_cur_simtime)   //high value means better, less vehicle connected
//          {
//              minTowerLoad = towerLoad(frame, lteInfo);
//              towerCount++;
//          }
//          sumbsLoadCal1 = bsLoadCal1Weighted + minTowerLoad;
//          if((int)simTime().dbl() % 10 == 0)
//          {
//              avgLoad = sumbsLoadCal1 / 10;
//              avgLoad = 1 - avgLoad;
//              sumbsLoadCal1 = 0;
//              towerCount = 0;
//              towerLoad_cur_simtime = simTime().dbl();
////              std::cout << "Tower: " << lteInfo->getSourceId() <<" Avg Load: " << avgLoad << endl;
//          }
//}
//
//double calParameter::towerLoad(LteAirFrame* frame, UserControlInfo* lteInfo) {
//    int flag=0;
//    for (int i = 0; i < NUM_TOWERS; i++) {
//        bsLoadCal1[i] = (bsLoad[i] + 10) / (std::accumulate(bsLoad, bsLoad + NUM_TOWERS, 0) - bsLoad[i] + 10);
//        if (bsLoadCal1[i] >= minLoad && flag!=1) {
//            minLoad = bsLoadCal1[i];
//            flag=1;
//        }
//    }
//
//    std::fill(std::begin(bsLoad), std::end(bsLoad), 0);
//    towerLoad_cur_simtime = simTime().dbl();
//
//    return minLoad;
//}
//
//void calParameter::runLSTM() {
//    std::string pypredLSTMFile;
//    std::string pypredLSTM_CmdPyCpp = "python3 " + baseFilePath + "lstmPred.py";
//    pypredLSTM_CmdPyCpp += pypredLSTMFile;
//    system(pypredLSTM_CmdPyCpp.c_str());
//}
//
//double calParameter::getParfromFile(std::string filepath) {
//    std::ifstream file(filepath);
//    std::string parData;
//    double parDouble = 0;
//    while (std::getline(file, parData))
//    {
//        parDouble = atof(parData.c_str());
//    }
//    file.close();
//    return parDouble;
//}
//
//


void calParameter::runGPR() {
    std::string pypredGPRFile;
    std::string pypredGPR_CmdPyCpp = "python3 " + baseFilePath + "gRP.py";
    pypredGPR_CmdPyCpp += pypredGPRFile;
    system(pypredGPR_CmdPyCpp.c_str());
}

double calParameter::getDoubleValueFile(std::string filepath)
{
    std::ifstream file(filepath);
    std::string valueData;
    double valueDouble = 0;
    while (std::getline (file, valueData))
    {
        valueDouble = atof(valueData.c_str());
    }
    file.close();
    return valueDouble;
}


void calParameter::runLSTM() {
    std::string lstmScriptPath = baseFilePath + "lstm.py";
    std::string lstmCmd = "python3 " + lstmScriptPath;
    std::cout << "Executing LSTM script: " << lstmCmd << std::endl;
    int result = system(lstmCmd.c_str());
    if (result != 0) {
        std::cerr << "Error: Failed to execute LSTM script!" << std::endl;
        prediction_4g = 0.1; // Fallback
        prediction_5g = 0.1; // Fallback
        return;
    }

    // Read predictions once after running the script
    std::ifstream inFile4g(baseFilePath + "outputLSTM_4G.txt");
    if (inFile4g.is_open()) {
        std::string line;
        if (std::getline(inFile4g, line)) {
            prediction_4g = std::stod(line);
        }
        inFile4g.close();
    }

    std::ifstream inFile5g(baseFilePath + "outputLSTM_5G.txt");
    if (inFile5g.is_open()) {
        std::string line;
        if (std::getline(inFile5g, line)) {
            prediction_5g = std::stod(line);
        }
        inFile5g.close();
    }
}
//void calParameter::runLSTM() {
//    std::string lstmScriptPath = baseFilePath + "lstm.py";
//    std::string lstmCmd = "python3 " + lstmScriptPath;
//
//    // Execute the LSTM script
//    std::cout << "Executing LSTM script: " << lstmCmd << std::endl;
//    int result = system(lstmCmd.c_str());
//    if (result != 0) {
//        std::cerr << "Error: Failed to execute LSTM script!" << std::endl;
//        return;
//    }
//
//    // Read the predicted 4G and 5G loads from the output files
//    std::string outputFile4G = baseFilePath + "outputLSTM_4G.txt";
//    std::string outputFile5G = baseFilePath + "outputLSTM_5G.txt";
//
//    double predictedLoad4G = getDoubleValueFile(outputFile4G);
//    double predictedLoad5G = getDoubleValueFile(outputFile5G);
//
//    std::cout << "Predicted 4G Load: " << predictedLoad4G << std::endl;
//    std::cout << "Predicted 5G Load: " << predictedLoad5G << std::endl;
//
//    // Optionally, store these predictions in class variables or use them directly
//    predictedLoad4G_global = predictedLoad4G; // Add these variables to calParameter.h
//    predictedLoad5G_global = predictedLoad5G;
//}
